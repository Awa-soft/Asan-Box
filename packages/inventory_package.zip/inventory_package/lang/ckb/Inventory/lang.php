<?php
return [
    "group_label"=>"کاڵاکان",
    "category" =>[
        "plural_label"=>""
    ],
];
