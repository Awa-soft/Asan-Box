<?php
return [
    "group_label"=>"Inventory",
    "category" =>[
        "plural_label"=>"Categories",
        "singular_label"=>"Category",
    ],
    "brand" =>[
        "plural_label"=>"Brands",
        "singular_label"=>"Brand",
    ],
    "unit" =>[
        "plural_label"=>"Units",
        "singular_label"=>"Unit",
    ],
    "item" =>[
        "plural_label"=>"Items",
        "singular_label"=>"Item",
    ],

  
];
